// app/functions/sendOrderEmail.ts
//import { SESClient, SendEmailCommand } from "@aws-sdk/client-ses";

