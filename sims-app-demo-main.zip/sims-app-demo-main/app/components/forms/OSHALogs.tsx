// app/components/forms/OSHALogs.tsx
'use client';

import React from 'react';

export default function OSHALogs(){

    return (
        <div>
           <h2 className="text-lg font-bold mb-4 text-rose-700">OSHA Logs (future item)</h2> 
        </div>
    );

}