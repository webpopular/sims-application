///app/(dashboard)/admin/settings/page.tsx
'use client';

export default function AdminSettingsPage() {
  return (
    <div>
      <h1>Admin Settings</h1>
      {/* settings page content here */}
    </div>
  );
}
