//app/(dashboard)/incident-investigations/page.tsx
import InvestigationList from '@/app/components/forms/InvestigationList';

export default function InvestigationsPage() {
  return <InvestigationList />;
}
