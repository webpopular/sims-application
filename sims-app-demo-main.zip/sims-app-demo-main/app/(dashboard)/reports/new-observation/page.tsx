// app/reports/new-observation/page.tsx
import ObservationReportForm from "@/app/components/forms/ObservationReportForm";

export default function NewObservationPage(){
    return <ObservationReportForm />;
}