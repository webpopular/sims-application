//app/reports/new-safety-recognition/page.tsx
import RecognitionForm from "@/app/components/forms/RecognitionForm";

export default function RecognitionPage(){
    return <RecognitionForm />;
}