export default function admin() {
    return(
        <div>
            List of Injuries
        </div>
    )


}