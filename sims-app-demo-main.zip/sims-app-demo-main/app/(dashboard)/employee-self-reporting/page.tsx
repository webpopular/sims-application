///app/(dashboard)/employee-self-reporting/page.tsx
'use client';

export default function EmployeeSelfReportingPage() {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">Employee Self Reporting</h1>
      {/* self-reporting form or content here */}
    </div>
  );
}
