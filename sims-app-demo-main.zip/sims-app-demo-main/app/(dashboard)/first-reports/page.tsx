'use client';

export default function FirstReportsPage() {
  return (
    <div className="container mx-auto p-4">
      <h1 className="text-2xl font-bold mb-4">FirstReportsPage</h1>
      {/* Add your self-reporting form or content here */}
    </div>
  );
}
