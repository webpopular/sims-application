 
 

export default function Sample() {
  return (
    <div className="p-2">
      <div className="max-w-6xl mx-auto">
      List..
       </div>
    </div>
  );    
}