// app/(dashboard)/first-reports/injury/page.tsx
// app/(dashboard)/first-reports/injury/page.tsx
import InjuryReportList from '@/app/components/forms/InjuryList';

export default function InjuryReportsPage() {
  return <InjuryReportList />;
}
