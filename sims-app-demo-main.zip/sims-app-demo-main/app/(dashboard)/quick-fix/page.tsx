//app/(dashboard)/quick-fix/page.tsx

import QuickFixComponent from '@/app/components/forms/QuickFix';

export default function QuickFixPage() {
  return <QuickFixComponent />;
}
