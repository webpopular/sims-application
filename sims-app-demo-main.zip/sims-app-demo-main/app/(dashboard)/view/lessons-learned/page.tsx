export default function Sample() {
  return (
    <div className="p-2">
      <div className="max-w-6xl mx-auto">
        <h2 className="text-lg font-bold mb-4 text-emerald-700">Lessons Learned</h2>

       </div>
    </div>
  );   
  }
