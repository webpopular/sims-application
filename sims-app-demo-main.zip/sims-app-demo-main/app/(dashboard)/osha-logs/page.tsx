//app/(dashboard)/osha-logs/page.tsx

import OSHALogs from '@/app/components/forms/OSHALogs';
//import { Metadata } from 'next';
/*
export const metadata: Metadata = {
  title: 'Manage OSHA Logs',
  description: 'View and manage OSHA logs.',
};*/

export default function OSHALogsPage() {
   return <OSHALogs />;
}
