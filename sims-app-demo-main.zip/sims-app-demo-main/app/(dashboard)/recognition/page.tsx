//app/(dashboard)/recognition/page.tsx
import RecognitionList from '@/app/components/forms/RecognitionList';

export default function RecognitionListPage() {
  return <RecognitionList />;
}

