// app/types/api.ts
import { Schema } from '../amplify/data/schema';

export type SubmissionType = Schema['Submission'];